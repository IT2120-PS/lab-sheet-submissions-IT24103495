setwd("C:\\Users\\it24103495\\Desktop\\IT24103495")
getwd

## Question 01
Delivery_Times<-read.table("Exercise - Lab 05.txt", header=TRUE)
Delivery_Times

## Question 02
histogram<-hist(Delivery_Times$Delivery,
                main="Histogram of Delivery Times",
                xlab = "Delivery Time",
                ylab = "Frequency",
                breaks = seq(20, 70,length = 10),
                right = FALSE)

## Question 03
##This is a Right-skewed distribution




## Question 04
# Extract histogram components
breaks <- histogram$breaks
freq <- histogram$counts
mid <- histogram$mids

# Generate class intervals
classes <- c()
for(i in 1:(length(breaks) - 1)) {
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

# Create frequency table
freq_table <- cbind(Classes = classes, Frequency = freq)
print(freq_table)

# Cumulative frequency
cum.freq <- cumsum(freq)
new <- c(0, cum.freq)

# Plot cumulative frequency polygon (Ogive)
plot(breaks, new, type = 'o',
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time",
     ylab = "Cumulative Frequency")

# Show table of upper boundaries and cumulative frequency
cum_table <- cbind(Upper = breaks, CumFreq = new)
print(cum_table)

