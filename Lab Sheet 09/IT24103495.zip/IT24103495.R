setwd("C:\\Users\\litha\\OneDrive\\Desktop\\it24103495")

# (i) Generate a random sample of size 25
set.seed(123)  # for reproducibility
sample <- rnorm(25, mean = 45, sd = 2)
sample

# Display sample mean
mean_sample <- mean(sample)
mean_sample

# (ii) Hypothesis Test
# H0: mu = 46
# H1: mu < 46
# alpha = 0.05

t_test_result <- t.test(sample, mu = 46, alternative = "less")
t_test_result

