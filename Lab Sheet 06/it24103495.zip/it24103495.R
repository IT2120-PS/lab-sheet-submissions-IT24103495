setwd("C:\\Users\\litha\\OneDrive\\Desktop\\it24103495")

# Q1 (i) Distribution of X
n <- 50
p <- 0.85
cat("X ~ Binomial(", n, ",", p, ")\n")

# Q1 (ii) Probability that at least 47 students passed
prob_47_or_more <- pbinom(46, size=n, prob=p, lower.tail=FALSE)
prob_47_or_more

# Q2 (i) Random variable
cat("X = number of customer calls per hour\n")

# Q2 (ii) Distribution
lambda <- 12
cat("X ~ Poisson(", lambda, ")\n")

# Q2 (iii) Probability of exactly 15 calls
prob_15_calls <- dpois(15, lambda)
prob_15_calls

